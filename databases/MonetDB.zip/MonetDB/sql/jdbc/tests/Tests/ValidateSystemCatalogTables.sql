\vsci_noheader
\vsni_noheader
\vsgi_noheader
\vsi_noheader sys
\vsi_noheader tmp
\vdbi_noheader

