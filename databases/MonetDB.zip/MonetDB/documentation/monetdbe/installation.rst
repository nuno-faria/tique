Installation
============

The ``libmonetdbe.so`` can be downloaded from the location...
