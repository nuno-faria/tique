********************
monetdbd manual page
********************

.. include:: manual_pages/monetdbd.rst.in
