********************
msqldump manual page
********************

.. include:: manual_pages/msqldump.rst
