********************
mserver5 manual page
********************

.. include:: manual_pages/mserver5.rst.in
